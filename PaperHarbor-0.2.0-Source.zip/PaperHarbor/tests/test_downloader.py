"""Local fixtures only: no literature or external services are downloaded."""
import io
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import downloader as dl
from pypdf import PdfWriter


def make_pdf():
    stream = io.BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=100, height=100)
    writer.write(stream)
    return stream.getvalue()


def make_zip():
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("data.csv", "x,y\n1,2\n")
    return stream.getvalue()


PDF = make_pdf()
ZIP = make_zip()


class FixtureHandler(BaseHTTPRequestHandler):
    counts = {}

    def log_message(self, *args):
        pass

    def do_GET(self):
        cls = type(self)
        cls.counts[self.path] = cls.counts.get(self.path, 0) + 1
        if self.path == "/redirect-private":
            self.send_response(302)
            self.send_header("Location", "http://192.168.3.4/secret.pdf")
            self.end_headers()
            return
        if self.path == "/retry.pdf" and cls.counts[self.path] == 1:
            self.send_error(503)
            return
        if self.path == "/slow.pdf":
            self.send_response(200)
            self.send_header("Content-Type", "application/pdf")
            self.send_header("Content-Length", str(len(PDF)))
            self.end_headers()
            try:
                for byte in PDF:
                    self.wfile.write(bytes([byte]))
                    self.wfile.flush()
                    time.sleep(.004)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            return
        if self.path in {"/paper.pdf", "/retry.pdf"}:
            content, kind = PDF, "application/pdf"
        elif self.path == "/large.pdf":
            content, kind = PDF + b"x" * 2048, "application/pdf"
        elif self.path == "/broken.pdf":
            content, kind = b"%PDF-1.7\ntruncated", "application/pdf"
        elif self.path in {"/html.pdf", "/supplement-html.pdf"}:
            content, kind = b"<html><body>Please log in</body></html>", "text/html"
        elif self.path == "/landing":
            content = b'''<html><head><meta name="citation_pdf_url" content="/paper.pdf"></head><body><a href="/data.csv">Supplementary data</a><a href="/archive.zip">Supporting information</a><a href="/unrelated.txt">Other article</a></body></html>'''
            kind = "text/html"
        elif self.path == "/landing-manual":
            content = b'<html><a href="/support-info">Supplementary information</a><a href="/danger.exe">Supporting data tool</a></html>'
            kind = "text/html"
        elif self.path == "/landing-partial":
            content = b'<html><a href="/data.csv">Supplementary table</a><a href="/supplement-html.pdf">Supplementary appendix</a></html>'
            kind = "text/html"
        elif self.path == "/landing-none":
            content, kind = b"<html><h1>Ordinary article</h1></html>", "text/html"
        elif self.path == "/landing-challenge":
            content, kind = b"<html>Verify you are human</html>", "text/html"
        elif self.path == "/data.csv":
            content, kind = b"x,y\n1,2\n", "text/csv"
        elif self.path == "/archive.zip":
            content, kind = ZIP, "application/zip"
        elif self.path == "/forbidden":
            self.send_error(403)
            return
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)


class DownloaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), FixtureHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = "http://127.0.0.1:" + str(cls.server.server_port)
        cls.tmp_parent = Path(__file__).parent / ".tmp"
        cls.tmp_parent.mkdir(exist_ok=True)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)
        try:
            cls.tmp_parent.rmdir()
        except OSError:
            pass

    def setUp(self):
        FixtureHandler.counts.clear()
        self.tmp = tempfile.TemporaryDirectory(dir=self.tmp_parent)
        self.out = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def paper(self, suffix="one", pdf="/paper.pdf", landing="/landing", **extra):
        result = {"id": suffix, "title": "Volterra: / tests? " + suffix, "year": 2025, "doi": "", "url": self.url + landing if landing else "", "oa": True, "pdf_urls": [self.url + pdf] if pdf else [], "sources": ["fixture"]}
        result.update(extra)
        return result

    def batch(self, papers, **kwargs):
        return dl.download_batch(papers, self.out, allow_local=True, **kwargs)

    def assert_no_parts(self):
        self.assertEqual(list(self.out.glob("*.part")), [])
        self.assertEqual(list(self.out.glob(".*.part")), [])

    def test_full_pdf_supplements_and_verified_cache(self):
        events = []
        paper = self.paper()
        paper["pdf_locations"] = [{"url": self.url + "/paper.pdf", "license": "cc-by", "version": "publishedVersion", "source": "OpenAlex", "is_oa": True}]
        first = self.batch([paper], progress=events.append)
        result = first["results"][0]
        self.assertEqual(result["status"], "downloaded")
        self.assertEqual(result["si_status"], "downloaded")
        self.assertEqual(len(result["supplements"]), 2)
        self.assertEqual(result["pdf_location"]["version"], "publishedVersion")
        self.assertEqual(first["summary"]["supplements_downloaded"], 2)
        self.assertTrue(Path(result["path"]).is_file())
        self.assertEqual(len(result["sha256"]), 64)
        self.assertIn("pypdf", result["validation"])
        self.assertTrue(any(x["status"] == "supplements" for x in events))
        before = dict(FixtureHandler.counts)
        second = self.batch([paper])
        again = second["results"][0]
        self.assertEqual(again["status"], "existing")
        self.assertEqual(again["si_status"], "existing")
        self.assertEqual(FixtureHandler.counts["/paper.pdf"], before["/paper.pdf"])
        self.assertEqual(FixtureHandler.counts["/data.csv"], before["/data.csv"])
        self.assertNotIn("/danger.exe", FixtureHandler.counts)
        self.assertNotIn("/unrelated.txt", FixtureHandler.counts)
        self.assert_no_parts()

    def test_html_is_not_pdf_and_manifest_survives_failure(self):
        result = self.batch([self.paper(pdf="/html.pdf", landing="/landing-none")])
        row = result["results"][0]
        self.assertEqual(row["status"], "failed")
        self.assertEqual(row["si_status"], "not_identified")
        self.assertIn("不代表", row["si_message"])
        self.assertEqual(list(self.out.glob("*.pdf")), [])
        manifest = json.loads(Path(result["manifest_path"]).read_text(encoding="utf-8"))
        self.assertEqual(manifest["results"][0]["id"], "one")
        self.assert_no_parts()

    def test_pdf_fallback_and_partial_supplement_validation(self):
        paper = self.paper(landing="/landing-partial")
        paper["pdf_urls"] = [self.url + "/broken.pdf", self.url + "/paper.pdf"]
        row = self.batch([paper])["results"][0]
        self.assertEqual(row["status"], "downloaded")
        self.assertEqual(len(row["attempts"]), 1)
        self.assertEqual(row["si_status"], "partial")
        self.assertEqual([s["status"] for s in row["supplements"]], ["downloaded", "failed"])
        self.assert_no_parts()

    def test_oa_landing_metadata_and_provider_fields(self):
        paper = self.paper(pdf=None, landing="/forbidden", oa_urls=[self.url + "/landing"])
        row = self.batch([paper])["results"][0]
        self.assertEqual(row["status"], "downloaded")
        self.assertEqual(row["si_status"], "partial")
        self.assertEqual(row["si_checked_urls"][0], self.url + "/landing")
        self.assertTrue(row["si_page_errors"])
        self.assertIn(self.url + "/landing", row["manual_urls"])

    def test_blocked_page_and_no_links_are_distinct(self):
        results = self.batch([self.paper("blocked", landing="/forbidden"), self.paper("none", landing="/landing-none"), self.paper("challenge", landing="/landing-challenge")])["results"]
        self.assertEqual([x["si_status"] for x in results], ["failed", "not_identified", "failed"])
        self.assertIn("未完成", results[0]["si_message"])

    def test_corrupt_existing_files_are_preserved_and_redownloaded(self):
        paper = self.paper()
        first = self.batch([paper])["results"][0]
        old_pdf = Path(first["path"])
        old_csv = Path(first["supplements"][0]["path"])
        old_pdf.write_text("<html>corrupt</html>")
        old_csv.write_bytes(b"\x00\x00corrupt")
        again = self.batch([paper])["results"][0]
        self.assertEqual(again["status"], "downloaded")
        self.assertNotEqual(first["path"], again["path"])
        self.assertEqual(again["supplements"][0]["status"], "downloaded")
        self.assertEqual(again["supplements"][1]["status"], "existing")
        self.assertEqual(old_pdf.read_text(), "<html>corrupt</html>")
        self.assert_no_parts()

    def test_cancelled_queue_records_every_selection(self):
        cancel = threading.Event()
        cancel.set()
        result = self.batch([self.paper("a"), self.paper("b")], cancel_event=cancel)
        self.assertEqual(result["summary"]["cancelled"], 2)
        self.assertEqual(FixtureHandler.counts, {})
        self.assertTrue(Path(result["manifest_path"]).is_file())
        self.assert_no_parts()

    def test_cancel_during_supplements_preserves_completed_main(self):
        cancel = threading.Event()
        def progress(event):
            if event["status"] == "supplements":
                cancel.set()
        result = self.batch([self.paper()], cancel_event=cancel, progress=progress)["results"][0]
        self.assertEqual(result["status"], "downloaded")
        self.assertEqual(result["si_status"], "cancelled")
        self.assertTrue(Path(result["path"]).exists())
        self.assert_no_parts()

    def test_duplicate_selection_only_downloads_once(self):
        paper = self.paper()
        result = self.batch([paper, paper], include_supplements=False)
        self.assertEqual(result["summary"]["total"], 1)
        self.assertEqual(FixtureHandler.counts["/paper.pdf"], 1)
        self.assertEqual(result["results"][0]["si_status"], "skipped")

    def test_retry_transient_http(self):
        row = self.batch([self.paper(pdf="/retry.pdf")], include_supplements=False)["results"][0]
        self.assertEqual(row["status"], "downloaded")
        self.assertEqual(FixtureHandler.counts["/retry.pdf"], 2)

    def test_size_limit(self):
        with patch.object(dl, "MAX_PDF_BYTES", 1024):
            row = self.batch([self.paper(pdf="/large.pdf")], include_supplements=False)["results"][0]
        self.assertEqual(row["status"], "failed")
        self.assertIn("大小", row["error"])
        self.assert_no_parts()

    def test_private_targets_credentials_and_redirect_are_rejected(self):
        for url in ["file:///C:/secret", "https://user:password@example.com/file.pdf", "http://127.0.0.1/test", "http://192.168.1.2/test", "http://169.254.169.254/meta", "http://[::1]/a"]:
            with self.subTest(url=url), self.assertRaises(dl.DownloadError):
                dl.validate_url(url)
        with patch.object(socket, "getaddrinfo", return_value=[(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.0.0.1", 443))]):
            with self.assertRaises(dl.DownloadError):
                dl.validate_url("https://public-name.example/file")
        row = self.batch([self.paper(pdf="/redirect-private")], include_supplements=False)["results"][0]
        self.assertEqual(row["status"], "failed")
        self.assertIn("私有", row["error"])

    def test_no_local_allowance_by_default(self):
        row = dl.download_batch([self.paper()], self.out, include_supplements=False)["results"][0]
        self.assertEqual(row["status"], "failed")
        self.assertEqual(FixtureHandler.counts, {})

    def test_empty_selection_still_has_manifest(self):
        result = self.batch([])
        self.assertEqual(result["summary"]["total"], 0)
        self.assertTrue(Path(result["manifest_path"]).is_file())

    def test_openalex_oa_resolution_candidates(self):
        paper = self.paper(pdf=None, landing="/landing-none", doi="10.1234/test")
        with patch.object(dl, "_resolve_openalex", return_value=([self.url + "/paper.pdf"], [self.url + "/landing"], [])) as resolve:
            row = self.batch([paper])["results"][0]
        resolve.assert_called_once()
        self.assertEqual(row["status"], "downloaded")
        self.assertEqual(len(row["supplements"]), 2)


    def test_unsupported_supplement_entry_keeps_manual_link(self):
        row = self.batch([self.paper(landing="/landing-manual")])["results"][0]
        self.assertEqual(row["si_status"], "incomplete")
        self.assertEqual(len(row["si_manual_links"]), 2)
        self.assertIn(self.url + "/support-info", row["manual_urls"])
        self.assertNotIn("/danger.exe", FixtureHandler.counts)

    def test_total_download_time_limit(self):
        with patch.object(dl, "MAX_DOWNLOAD_SECONDS", -1):
            row = self.batch([self.paper()], include_supplements=False)["results"][0]
        self.assertEqual(row["status"], "failed")
        self.assertIn("总时限", row["error"])
        self.assert_no_parts()

    def test_cancelled_retry_preserves_existing_cache(self):
        paper = self.paper()
        first = self.batch([paper])["results"][0]
        cancel = threading.Event()
        cancel.set()
        cancelled = self.batch([paper], cancel_event=cancel)["results"][0]
        self.assertTrue(cancelled["previous_sidecar_preserved"])
        again = self.batch([paper])["results"][0]
        self.assertEqual(again["status"], "existing")
        self.assertEqual(again["si_status"], "existing")
        self.assertEqual(FixtureHandler.counts["/data.csv"], 1)



    def test_slow_trickle_obeys_total_deadline(self):
        started = time.monotonic()
        with patch.object(dl, "MAX_DOWNLOAD_SECONDS", .08):
            row = self.batch([self.paper(pdf="/slow.pdf")], include_supplements=False)["results"][0]
        self.assertEqual(row["status"], "failed")
        self.assertIn("总时限", row["error"])
        self.assertLess(time.monotonic() - started, 1.5)
        self.assert_no_parts()



    def test_plos_s1_attachment_and_author_guidance_are_distinct(self):
        parser = dl._LandingParser("https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0301505")
        parser.feed('''<nav><a href="/plosone/s/supporting-information">Supporting Information</a><a href="/plosone/s/submission-guidelines">Supplementary file guidelines</a></nav>
          <section><a href="/plosone/article/file?id=10.1371%2Fjournal.pone.0301505.s001&amp;type=supplementary"><strong>S1 File.</strong> Numerical code and results.</a>
          <a href="/plosone/article/file?id=10.1371/journal.pone.0301505.s002&amp;type=supplementary">S2 Appendix.</a></section>''')
        self.assertEqual(len(parser.supplements), 2)
        self.assertEqual(parser.manual_supplements, [])
        self.assertIn("type=supplementary", parser.supplements[0]["url"])

    def test_article_route_without_supplement_id_is_not_auto_downloaded(self):
        parser = dl._LandingParser("https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0301505")
        parser.feed('<a href="/plosone/article/file?id=10.1371/journal.pone.0301505&amp;type=printable">Supporting information</a>')
        self.assertEqual(parser.supplements, [])
        self.assertEqual(len(parser.manual_supplements), 1)


if __name__ == "__main__":
    unittest.main()
