"""Offline tests for provider normalization, bounded failures and cancellation."""
import io
import json
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch

import providers as p


ATOM_SAMPLE = '''<feed xmlns="http://www.w3.org/2005/Atom"
 xmlns:arxiv="http://arxiv.org/schemas/atom"
 xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
 <opensearch:totalResults>1</opensearch:totalResults><entry>
 <id>http://arxiv.org/abs/2401.01234v2</id><published>2024-01-03T00:00:00Z</published>
 <title>A study\n of Volterra equations</title><summary>Some abstract.</summary>
 <author><name>Alice Smith</name></author><arxiv:doi>https://doi.org/10.1234/ABC</arxiv:doi>
 <arxiv:journal_ref>Journal X 2025</arxiv:journal_ref><category term="math.NA"/>
 <link title="pdf" href="http://arxiv.org/pdf/2401.01234v2" type="application/pdf"/>
 </entry></feed>'''


def record(title, doi="", citations=None, year=2024):
    return {"id": title, "title": title, "authors": [], "year": year,
            "venue": "", "doi": doi, "arxiv_id": "", "abstract": "", "url": "",
            "pdf_urls": [], "sources": [], "version": "文献", "oa": False,
            "citations": citations}


class NormalizeTests(unittest.TestCase):
    def test_openalex_only_explicit_oa_pdf_links(self):
        item = {"id": "https://openalex.org/W123", "display_name": "Test", "type": "article",
            "doi": "https://doi.org/10.1234/ABC", "publication_year": 2024,
            "primary_location": {"source": {"type": "journal", "display_name": "Journal"},
                                 "is_oa": False, "pdf_url": "https://publisher.test/paid.pdf"},
            "best_oa_location": {"is_oa": True, "pdf_url": "https://repository.test/paper.pdf",
                                 "landing_page_url": "https://repository.test/item/1", "version": "acceptedVersion"},
            "locations": [{"is_oa": True, "pdf_url": "javascript:alert(1)"}],
            "abstract_inverted_index": {"Volterra": [0], "equations": [1]},
            "authorships": [{"author": {"display_name": "A Person"}}]}
        result = p._normalize_openalex(item)
        self.assertEqual(result["doi"], "10.1234/abc")
        self.assertEqual(result["pdf_urls"], ["https://repository.test/paper.pdf"])
        self.assertEqual(result["version"], "期刊论文")
        self.assertEqual(result["abstract"], "Volterra equations")
        self.assertTrue(result["oa"])
        self.assertEqual(result["pdf_locations"][0]["version"], "acceptedVersion")

    def test_arxiv_is_still_preprint_even_with_journal_reference(self):
        entry = ET.fromstring(ATOM_SAMPLE).find(p.ATOM + "entry")
        result = p._normalize_arxiv(entry)
        self.assertEqual(result["version"], "预印本")
        self.assertEqual(result["journal_reference"], "Journal X 2025")
        self.assertEqual(result["pdf_urls"], ["https://arxiv.org/pdf/2401.01234v2"])
        self.assertEqual(result["doi"], "10.1234/abc")
        self.assertEqual(result["year"], 2024)
        self.assertEqual(result["title"], "A study of Volterra equations")
        self.assertEqual(p._arxiv_id("https://arxiv.org/pdf/math/0301234v1.pdf"), "math/0301234v1")
        self.assertEqual(p._arxiv_id("https://evil.test/pdf/2401.01234"), "")

    def test_crossref_does_not_treat_tdm_link_as_oa(self):
        result = p._normalize_crossref({"title": ["Title"], "DOI": "10.1/test",
            "type": "journal-article", "published": {"date-parts": [[2020, 4, 1]]},
            "link": [{"URL": "https://publisher.test/paper.pdf", "content-type": "application/pdf"}],
            "author": [{"given": "Alice", "family": "Smith"}]})
        self.assertEqual(result["pdf_urls"], [])
        self.assertFalse(result["oa"])
        self.assertEqual(result["oa_status"], "unknown")
        self.assertEqual(result["year"], 2020)
        self.assertEqual(result["authors"], ["Alice Smith"])

    def test_publisher_and_issn_metadata(self):
        crossref = p._normalize_crossref({"publisher": "Elsevier BV", "ISSN": ["1234-5678", "1234-5678"], "container-title": ["Journal X"]})
        self.assertEqual(crossref["publisher"], "Elsevier BV")
        self.assertEqual(crossref["issns"], ["1234-5678"])
        self.assertEqual(crossref["venue"], "Journal X")
        alex = p._normalize_openalex({"primary_location": {"source": {
            "type": "journal", "display_name": "Journal Y", "host_organization_name": "Wiley", "issn": ["8765-4321"], "issn_l": "8765-4321"}}})
        self.assertEqual(alex["publisher"], "Wiley")
        self.assertEqual(alex["issns"], ["8765-4321"])
        repository = p._normalize_openalex({"primary_location": {"source": {"type": "repository", "host_organization_name": "University"}}})
        self.assertEqual(repository["publisher"], "")

    def test_missing_optional_metadata_is_safe(self):
        for fn in [p._normalize_openalex, p._normalize_crossref]:
            result = fn({})
            self.assertTrue(result["id"])
            self.assertEqual(result["title"], "（无标题）")
            self.assertIsNone(result["year"])

    def test_urls_reject_unsafe_schemes_and_credentials(self):
        for url in ["file:///D:/secret", "javascript:alert(1)", "https://u:p@example.org/a", "https://["]:
            self.assertEqual(p._safe_url(url), "")


class FetchTests(unittest.TestCase):
    def test_openalex_date_filters_and_sort(self):
        with patch.object(p, "_request", return_value=b'{"results":[],"meta":{"count":0}}') as req:
            result = p._fetch_source("openalex", "Volterra", 50, 2015, 2025, "year", None)
        url = req.call_args.args[0]
        params = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        self.assertEqual(params["per-page"], ["50"])
        self.assertEqual(params["sort"], ["publication_date:desc"])
        self.assertIn("from_publication_date:2015-01-01", params["filter"][0])
        self.assertIn("to_publication_date:2025-12-31", params["filter"][0])
        self.assertEqual(result["total"], 0)

    def test_crossref_complete_doi_uses_singleton_endpoint_once(self):
        item = {"DOI": "10.1234/ABC", "title": ["Exact paper"], "published": {"date-parts": [[2024]]}}
        for query in ("10.1234/ABC", "doi: 10.1234/ABC", "https://doi.org/10.1234/ABC?utm_source=test"):
            with self.subTest(query=query), patch.object(p, "_request", return_value=json.dumps({"message": item}).encode()) as req:
                result = p._fetch_source("crossref", query, 100, None, None, "relevance", None)
            self.assertEqual(req.call_count, 1)
            url = req.call_args.args[0]
            self.assertEqual(urllib.parse.unquote(urllib.parse.urlsplit(url).path), "/works/10.1234/abc")
            self.assertEqual(urllib.parse.urlsplit(url).query, "")
            self.assertEqual(result["total"], 1)
            self.assertEqual(len(result["papers"]), 1)
            self.assertTrue(result["exhausted"])
            self.assertEqual(result["pages"], 1)

    def test_crossref_doi_inside_text_keeps_bibliographic_query(self):
        with patch.object(p, "_request", return_value=b'{"message":{"items":[],"total-results":0}}') as req:
            p._fetch_source("crossref", "paper 10.1234/abc", 10, None, None, "relevance", None)
        params = urllib.parse.parse_qs(urllib.parse.urlsplit(req.call_args.args[0]).query)
        self.assertEqual(params["query.bibliographic"], ["paper 10.1234/abc"])

    def test_crossref_exact_doi_404_is_explicit_empty_result(self):
        with patch.object(p, "_request", side_effect=p.ProviderError("HTTP 404", status_code=404)):
            result = p._fetch_source("crossref", "10.1234/absent", 30, None, None, "relevance", None)
        self.assertEqual(result["papers"], [])
        self.assertEqual(result["total"], 0)
        self.assertTrue(result["complete"])
        self.assertTrue(any("404" in w and "未找到" in w for w in result["warnings"]))

    def test_crossref_exact_doi_network_failure_is_not_empty_success(self):
        with patch.object(p, "_request", side_effect=p.ProviderError("网络连接失败")):
            with self.assertRaisesRegex(p.ProviderError, "网络连接失败"):
                p._fetch_source("crossref", "10.1234/abc", 30, None, None, "relevance", None)

    def test_crossref_exact_doi_year_filter_is_inclusive_and_missing_year_visible(self):
        for year, start, end, count in [(2024, 2024, 2024, 1), (2023, 2024, None, 0),
                                        (2025, None, 2024, 0), (None, 2020, 2025, 0)]:
            item = {"DOI": "10.1234/abc", "title": ["Exact paper"]}
            if year is not None:
                item["published"] = {"date-parts": [[year]]}
            with self.subTest(year=year), patch.object(p, "_request", return_value=json.dumps({"message": item}).encode()):
                result = p._fetch_source("crossref", "10.1234/abc", 30, start, end, "year", None)
            self.assertEqual(len(result["papers"]), count)
            self.assertEqual(result["total"], count)
            if not count:
                self.assertTrue(any("年份" in w for w in result["warnings"]))

    def test_crossref_exact_doi_mismatched_record_is_rejected(self):
        with patch.object(p, "_request", return_value=b'{"message":{"DOI":"10.1234/other","title":["Other"]}}'):
            with self.assertRaisesRegex(p.ProviderError, "标识不符"):
                p._fetch_source("crossref", "10.1234/abc", 10, None, None, "relevance", None)

    def test_http404_status_remains_available_to_singleton_lookup(self):
        error = urllib.error.HTTPError("https://example.org", 404, "missing", {}, io.BytesIO())
        with patch.object(p.urllib.request, "urlopen", side_effect=error), patch.object(p, "_throttle_source"):
            with self.assertRaises(p.ProviderError) as raised:
                p._request("https://example.org", "crossref", None)
        self.assertEqual(raised.exception.status_code, 404)

    def test_arxiv_plain_keywords_use_and_and_no_forced_math_filter(self):
        query = p._arxiv_query('Volterra "integral equations"', 2010, 2025)
        self.assertIn('all:"Volterra" AND all:"integral equations"', query)
        self.assertIn("submittedDate:[201001010000 TO 202512312359]", query)
        self.assertNotIn("cat:", query)
        self.assertEqual(p._arxiv_query("ti:Volterra AND cat:math.NA", None, None), "ti:Volterra AND cat:math.NA")

    def test_arxiv_boolean_operators_and_parentheses_preserved(self):
        self.assertEqual(p._arxiv_query("Volterra OR Fredholm", None, None), 'all:"Volterra" OR all:"Fredholm"')
        self.assertEqual(p._arxiv_query('(Volterra OR Fredholm) "integral equations" NOT nonlinear', None, None),
                         '( all:"Volterra" OR all:"Fredholm" ) AND all:"integral equations" ANDNOT all:"nonlinear"')
        for query in ['Volterra OR', 'OR Volterra', '(Volterra OR Fredholm', 'Volterra)', '"Volterra']:
            with self.assertRaises(p.ProviderError):
                p._arxiv_query(query, None, None)

    def test_arxiv_atom_parsing(self):
        with patch.object(p, "_request", return_value=ATOM_SAMPLE.encode()):
            result = p._fetch_source("arxiv", "Volterra", 10, None, None, "citations", None)
        self.assertEqual(len(result["papers"]), 1)
        self.assertEqual(result["total"], 1)
        self.assertIn("不提供引用次数", result["warnings"][0])

    def test_arxiv_error_feed_is_not_silent_empty_success(self):
        error = '<feed xmlns="http://www.w3.org/2005/Atom"><entry><id>http://arxiv.org/api/errors#incorrect_id_format</id></entry></feed>'
        with patch.object(p, "_request", return_value=error.encode()):
            with self.assertRaises(p.ProviderError):
                p._fetch_source("arxiv", "bad", 10, None, None, "relevance", None)

    def test_xml_entities_rejected(self):
        with patch.object(p, "_request", return_value=b'<!DOCTYPE x><feed/>'):
            with self.assertRaises(p.ProviderError):
                p._fetch_source("arxiv", "bad", 10, None, None, "relevance", None)

    def test_http429_retries_are_bounded(self):
        def fail(*args, **kwargs):
            raise urllib.error.HTTPError("https://example.org", 429, "limited", {}, io.BytesIO())
        with patch.object(p.urllib.request, "urlopen", side_effect=fail) as op, patch.object(p, "_wait"):
            with self.assertRaisesRegex(p.ProviderError, "429"):
                p._request("https://example.org", "openalex", None)
        self.assertEqual(op.call_count, 2)

    def test_long_retry_after_not_ignored(self):
        error = urllib.error.HTTPError("https://example.org", 429, "limited", {"Retry-After": "90"}, io.BytesIO())
        with patch.object(p.urllib.request, "urlopen", side_effect=error) as op:
            with self.assertRaisesRegex(p.ProviderError, "429"):
                p._request("https://example.org", "openalex", None)
        self.assertEqual(op.call_count, 1)

    def test_retry_after_http_date_is_respected(self):
        error = urllib.error.HTTPError("https://example.org", 429, "limited",
            {"Retry-After": "Wed, 31 Dec 2098 23:59:59 GMT"}, io.BytesIO())
        with patch.object(p.urllib.request, "urlopen", side_effect=error) as op:
            with self.assertRaisesRegex(p.ProviderError, "429"):
                p._request("https://example.org", "openalex", None)
        self.assertEqual(op.call_count, 1)

    def test_cancellation_interrupts_backoff(self):
        event = threading.Event()
        event.set()
        with self.assertRaises(p.SearchCancelled):
            p._wait(10, event)


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.cache = patch.object(p, "CACHE_DIR", Path(self.temp.name))
        self.cache.start()

    def tearDown(self):
        self.cache.stop()
        self.temp.cleanup()

    def test_source_failure_keeps_other_results(self):
        def fetch(source, *args, **kwargs):
            if source == "arxiv":
                raise p.ProviderError("测试网络失败。")
            return {"papers": [record("Good")], "total": 1, "warnings": []}
        with patch.object(p, "_fetch_source", side_effect=fetch):
            result = p.search("Volterra", sources=["openalex", "arxiv"])
        self.assertEqual(len(result["papers"]), 1)
        self.assertEqual(result["sources"]["arxiv"]["status"], "failed")
        self.assertTrue(any("arXiv" in w and "测试网络失败" in w for w in result["warnings"]))

    def test_exact_doi_does_not_reuse_legacy_bibliographic_cache(self):
        import hashlib
        query = "10.1234/abc"
        legacy_key = json.dumps([5, "crossref", query, 30, None, None, "relevance"], ensure_ascii=False)
        legacy_path = p.CACHE_DIR / ("crossref-" + hashlib.sha256(legacy_key.encode("utf8")).hexdigest() + ".json")
        p._write_cache(legacy_path, {"papers": [record("Wrong broad match", doi="10.1234/other")], "total": 6000000, "warnings": []})
        with patch.object(p, "_request", return_value=b'{"message":{"DOI":"10.1234/abc","title":["Exact paper"]}}') as req:
            result = p.search(query, sources=["crossref"])
        self.assertEqual(req.call_count, 1)
        self.assertEqual(result["papers"][0]["doi"], query)
        self.assertEqual(result["sources"]["crossref"]["total"], 1)
        self.assertFalse(result["sources"]["crossref"]["from_cache"])

    def test_fresh_cache_avoids_network_and_is_visible(self):
        data = {"papers": [record("Cached")], "total": 1, "warnings": []}
        path = p._cache_path("openalex", "Volterra", 30, None, None, "relevance")
        p._write_cache(path, data)
        with patch.object(p, "_fetch_source") as fetch:
            result = p.search("Volterra", sources=["openalex"])
        fetch.assert_not_called()
        self.assertEqual(result["sources"]["openalex"]["status"], "cached")
        self.assertTrue(any("不是本次实时获取" in w for w in result["warnings"]))

    def test_stale_cache_fallback_is_visible(self):
        path = p._cache_path("openalex", "Volterra", 30, None, None, "relevance")
        path.write_text(json.dumps({"papers": [record("Old")], "saved_at": time.time() - p.CACHE_TTL - 1,
                                    "total": 1, "warnings": []}), encoding="utf-8")
        with patch.object(p, "_fetch_source", side_effect=p.ProviderError("服务失败。")):
            result = p.search("Volterra", sources=["openalex"])
        self.assertEqual(result["sources"]["openalex"]["status"], "stale_cache")
        self.assertTrue(any("可能过期" in w for w in result["warnings"]))
        self.assertEqual(result["papers"][0]["title"], "Old")

    def test_malformed_cache_ignored(self):
        path = p._cache_path("openalex", "Volterra", 30, None, None, "relevance")
        path.write_text("not json", encoding="utf-8")
        with patch.object(p, "_fetch_source", return_value={"papers": [], "total": 0, "warnings": []}):
            result = p.search("Volterra", sources=["openalex"])
        self.assertEqual(result["sources"]["openalex"]["status"], "ok")

    def test_relevance_interleaves_sources_before_truncation(self):
        def fetch(source, *args, **kwargs):
            return {"papers": [record(source + str(i)) for i in range(4)], "total": 4, "warnings": []}
        with patch.object(p, "_fetch_source", side_effect=fetch), patch.object(p, "deduplicate", side_effect=lambda x:x):
            result = p.search("Volterra", limit=3)
        self.assertEqual([x["title"] for x in result["papers"]], ["openalex0", "arxiv0", "crossref0"])

    def test_cross_source_doi_dedup_normalizes_case_and_resolver(self):
        def fetch(source, *args, **kwargs):
            if source == "openalex":
                paper = record("Published paper", doi="https://doi.org/10.1234/ABC")
                paper.update(sources=["OpenAlex"], version="期刊论文",
                    pdf_urls=["https://repository.example/accepted.pdf"], oa=True)
            else:
                paper = record("Preprint title", doi="10.1234/abc")
                paper.update(sources=["arXiv"], version="预印本", arxiv_id="2401.01234v2",
                    pdf_urls=["https://arxiv.org/pdf/2401.01234v2"], oa=True)
            return {"papers": [paper], "total": 1, "warnings": []}
        with patch.object(p, "_fetch_source", side_effect=fetch):
            result = p.search("Volterra", sources=["openalex", "arxiv"])
        self.assertEqual(len(result["papers"]), 1)
        paper = result["papers"][0]
        self.assertEqual(paper["doi"], "10.1234/abc")
        self.assertEqual(set(paper["sources"]), {"OpenAlex", "arXiv"})
        self.assertEqual(set(paper["pdf_urls"]), {
            "https://repository.example/accepted.pdf", "https://arxiv.org/pdf/2401.01234v2"})
        self.assertTrue(paper["oa"])

    def test_citations_unknown_sorts_last(self):
        def fetch(source, *args, **kwargs):
            return {"papers": [record("Unknown", citations=None), record("Known", citations=0)], "total": 2, "warnings": []}
        with patch.object(p, "_fetch_source", side_effect=fetch):
            result = p.search("Volterra", sources=["openalex"], sort="citations")
        self.assertEqual(result["papers"][0]["title"], "Known")

    def test_precancelled_search_does_not_start_network(self):
        event = threading.Event()
        event.set()
        with patch.object(p, "_fetch_source") as fetch:
            result = p.search("Volterra", cancel_event=event)
        fetch.assert_not_called()
        self.assertTrue(result["cancelled"])
        self.assertEqual(result["papers"], [])

    def test_active_cancellation_returns_without_waiting_for_source(self):
        event, entered, release = threading.Event(), threading.Event(), threading.Event()
        def slow(*args, **kwargs):
            entered.set()
            release.wait(5)
            return {"papers": [], "total": 0, "warnings": []}
        def cancel():
            entered.wait(2)
            event.set()
        worker = threading.Thread(target=cancel)
        worker.start()
        start = time.monotonic()
        try:
            with patch.object(p, "_fetch_source", side_effect=slow):
                result = p.search("Volterra", sources=["openalex"], cancel_event=event)
            self.assertLess(time.monotonic() - start, 2)
            self.assertTrue(result["cancelled"])
        finally:
            release.set()
            worker.join(2)
            # Allow the background source to observe release before temporary cache cleanup.
            time.sleep(0.05)

    def test_api_default_sources_match_fresh_ui_settings(self):
        import core
        with patch.object(core, "DATA_DIR", Path(self.temp.name)), patch.object(p, "_fetch_source", return_value={"papers": [], "total": 0, "warnings": []}):
            defaults = core.load_settings()
            result = p.search("Volterra")
        self.assertEqual(set(result["sources"]), set(defaults["sources"]))

    def test_validation(self):
        for kwargs in [{"query":""}, {"query":"x", "limit":0}, {"query":"x", "limit":501},
                       {"query":"x", "year_from":2025, "year_to":2010},
                       {"query":"x", "sources":[]}, {"query":"x", "sources":["unknown"]}]:
            with self.assertRaises(ValueError):
                p.search(**kwargs)



class PaginationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.cache = patch.object(p, "CACHE_DIR", Path(self.temp.name))
        self.cache.start()

    def tearDown(self):
        self.cache.stop()
        self.temp.cleanup()

    @staticmethod
    def page(offset, size=100, total=500):
        rows = [record(f"Paper {i}", doi=f"10.1234/{i}") for i in range(offset, min(offset + size, total))]
        return {"papers": rows, "raw_count": len(rows), "total": total,
                "exhausted": offset + len(rows) >= total, "warnings": [], "next_cursor": None}

    def test_openalex_page_size_stays_fixed_for_nonmultiple_limit(self):
        urls = []
        def request(url, source, cancel):
            params = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
            urls.append(params)
            offset = (int(params["page"][0]) - 1) * int(params["per-page"][0])
            rows = [{"id": f"https://openalex.org/W{i}", "display_name": f"Paper {i}",
                     "doi": f"https://doi.org/10.1234/{i}"} for i in range(offset, offset + 100)]
            return json.dumps({"results": rows, "meta": {"count": 1000}}).encode()
        with patch.object(p, "_request", side_effect=request):
            result = p._fetch_source("openalex", "Volterra", 250, None, None, "relevance", None)
        self.assertEqual([v["page"][0] for v in urls], ["1", "2", "3"])
        self.assertEqual([v["per-page"][0] for v in urls], ["100", "100", "100"])
        self.assertEqual(len(result["papers"]), 250)
        self.assertEqual(len({x["doi"] for x in result["papers"]}), 250)
        self.assertEqual(result["raw_retrieved"], 300)
        self.assertEqual(result["pages"], 3)
        self.assertEqual(result["total"], 1000)
        self.assertTrue(result["complete"])
        self.assertEqual(result["end_reason"], "limit")

    def test_crossref_advances_offset_to_get_500_unique_results(self):
        offsets = []
        def request(url, source, cancel):
            params = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
            offset = int(params["offset"][0]); offsets.append(offset)
            items = [{"DOI": f"10.1234/{i}", "title": [f"Paper {i}"]} for i in range(offset, offset + 100)]
            return json.dumps({"message": {"items": items, "total-results": 999}}).encode()
        with patch.object(p, "_request", side_effect=request):
            result = p.search("Volterra", limit=500, sources=["crossref"])
        self.assertEqual(offsets, [0, 100, 200, 300, 400])
        self.assertEqual(len(result["papers"]), 500)
        self.assertTrue(result["sources"]["crossref"]["complete"])
        self.assertEqual(result["sources"]["crossref"]["pages"], 5)

    def test_arxiv_advances_start_and_stops_at_source_exhaustion(self):
        starts = []
        def request(url, source, cancel):
            params = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
            start = int(params["start"][0]); starts.append(start)
            root = ET.Element(p.ATOM + "feed")
            ET.SubElement(root, p.OPENSEARCH + "totalResults").text = "130"
            for i in range(start, min(start + 100, 130)):
                entry = ET.SubElement(root, p.ATOM + "entry")
                ET.SubElement(entry, p.ATOM + "id").text = f"https://arxiv.org/abs/2401.{i:05d}"
                ET.SubElement(entry, p.ATOM + "title").text = f"Paper {i}"
            return ET.tostring(root)
        with patch.object(p, "_request", side_effect=request):
            result = p._fetch_source("arxiv", "Volterra", 200, None, None, "relevance", None)
        self.assertEqual(starts, [0, 100])
        self.assertEqual(len(result["papers"]), 130)
        self.assertEqual(result["end_reason"], "exhausted")
        self.assertTrue(result["complete"])
        self.assertTrue(result["exhausted"])

    def test_second_page_failure_preserves_first_page_with_warning(self):
        def fetch(source, query, **kwargs):
            if kwargs["offset"]:
                raise p.ProviderError("测试 HTTP 429。")
            return self.page(0)
        with patch.object(p, "_fetch_page", side_effect=fetch):
            result = p.search("Volterra", limit=200, sources=["openalex"])
        self.assertEqual(len(result["papers"]), 100)
        status = result["sources"]["openalex"]
        self.assertEqual(status["status"], "partial")
        self.assertEqual(status["pages"], 1)
        self.assertEqual(status["retrieved"], 100)
        self.assertEqual(status["total"], 500)
        self.assertFalse(status["complete"])
        self.assertTrue(any("第 2 页失败" in s for s in result["warnings"]))
        cache = p._read_cache(p._cache_path("openalex", "Volterra", 200, None, None, "relevance"))
        self.assertFalse(cache["complete"])
        self.assertEqual(cache["source"], "openalex")

    def test_incomplete_fresh_cache_is_retried_not_claimed_complete(self):
        path = p._cache_path("openalex", "Volterra", 200, None, None, "relevance")
        p._write_cache(path, {**self.page(0), "complete": False, "pages": 1,
            "requested": 200, "end_reason": "page_failed", "raw_retrieved": 100})
        offsets = []
        def fetch(source, query, **kwargs):
            offsets.append(kwargs["offset"])
            return self.page(kwargs["offset"])
        with patch.object(p, "_fetch_page", side_effect=fetch):
            result = p.search("Volterra", limit=200, sources=["openalex"])
        self.assertEqual(offsets, [0, 100])
        self.assertEqual(len(result["papers"]), 200)
        self.assertEqual(result["sources"]["openalex"]["status"], "ok")
        self.assertTrue(p._read_cache(path)["complete"])

    def test_partial_fetch_does_not_overwrite_older_complete_cache(self):
        path = p._cache_path("openalex", "Volterra", 200, None, None, "relevance")
        p._write_cache(path, {**self.page(0, size=200), "complete": True, "pages": 2,
            "requested": 200, "end_reason": "limit", "raw_retrieved": 200})
        def fetch(source, query, **kwargs):
            if kwargs["offset"]:
                raise p.ProviderError("测试失败。")
            return self.page(0)
        with patch.object(p, "CACHE_TTL", 0), patch.object(p, "_fetch_page", side_effect=fetch):
            result = p.search("Volterra", limit=200, sources=["openalex"])
        self.assertFalse(result["sources"]["openalex"]["complete"])
        cached = p._read_cache(path)
        self.assertTrue(cached["complete"])
        self.assertEqual(len(cached["papers"]), 200)

    def test_cancellation_preserves_completed_page_without_waiting_for_socket(self):
        cancel, second_started, release, finished = [threading.Event() for _ in range(4)]
        def fetch(source, query, **kwargs):
            if kwargs["offset"] == 0:
                return self.page(0)
            second_started.set()
            release.wait(3)
            finished.set()
            raise p.SearchCancelled()
        def trigger_cancel():
            second_started.wait(2)
            cancel.set()
        trigger = threading.Thread(target=trigger_cancel)
        trigger.start()
        started = time.monotonic()
        try:
            with patch.object(p, "_fetch_page", side_effect=fetch):
                result = p.search("Volterra", limit=200, sources=["openalex"], cancel_event=cancel)
                self.assertLess(time.monotonic() - started, 2)
                self.assertTrue(result["cancelled"])
                self.assertEqual(len(result["papers"]), 100)
                self.assertEqual(result["sources"]["openalex"]["status"], "cancelled")
                self.assertFalse(result["sources"]["openalex"]["complete"])
                release.set()
                finished.wait(2)
        finally:
            release.set(); trigger.join(2)
            time.sleep(0.05)

    def test_repeated_pages_do_not_loop_until_limit(self):
        with patch.object(p, "_fetch_page", return_value=self.page(0)) as fetch:
            result = p._fetch_source("openalex", "Volterra", 500, None, None, "relevance", None)
        self.assertEqual(fetch.call_count, 3)
        self.assertEqual(len(result["papers"]), 100)
        self.assertFalse(result["complete"])
        self.assertEqual(result["end_reason"], "no_progress")

    def test_extra_provider_cursor_passed_between_pages(self):
        class Extra:
            SOURCE_NAMES = {"extra": "Extra"}
            def __init__(self): self.calls = []
            def fetch_page(self, source, query, **kwargs):
                self.calls.append(kwargs)
                offset = kwargs["offset"]
                return {"papers": [record(f"Extra {offset + i}") for i in range(2)],
                    "raw_count": 2, "total": 4, "warnings": [],
                    "next_cursor": "next-token" if offset == 0 else None, "exhausted": offset != 0}
        extra = Extra()
        with patch.object(p, "extra_providers", extra), patch.dict(p.SOURCE_NAMES, extra.SOURCE_NAMES), patch.dict(p.SOURCE_PAGE_SIZES, {"extra": 2}):
            result = p.search("Volterra", limit=4, sources=["extra"])
        self.assertEqual(len(result["papers"]), 4)
        self.assertIsNone(extra.calls[0]["cursor"])
        self.assertEqual(extra.calls[1]["cursor"], "next-token")
        self.assertEqual(extra.calls[1]["offset"], 2)
        self.assertTrue(callable(extra.calls[0]["request"]))


if __name__ == "__main__":
    unittest.main()
