import csv,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import core

class CoreTests(unittest.TestCase):
    def test_doi_merge_retains_versions_links_and_author_order(self):
        pre={"title":"Sample","doi":"https://doi.org/10.1234/ABC","year":2020,"authors":["A. One","B. Two"],"sources":["arXiv"],"version":"预印本","venue":"arXiv","url":"https://arxiv.org/abs/1234","pdf_urls":["https://arxiv.org/pdf/1234"],"oa_urls":["https://arxiv.org/abs/1234"],"pdf_locations":[{"url":"https://arxiv.org/pdf/1234","version":"submittedVersion"}]}
        final={**pre,"doi":"10.1234/abc","year":2021,"authors":["Alice One","Bob Two"],"sources":["Crossref"],"version":"期刊论文","venue":"Journal","url":"https://doi.org/10.1234/abc","pdf_urls":[],"oa_urls":[],"pdf_locations":[]}
        out=core.deduplicate([pre,final])
        self.assertEqual(len(out),1)
        self.assertEqual(out[0]["authors"],["Alice One","Bob Two"])
        self.assertEqual(out[0]["version"],"期刊论文")
        self.assertEqual(out[0]["year"],2021)
        self.assertEqual(out[0]["pdf_urls"],pre["pdf_urls"])
        self.assertEqual(out[0]["oa_urls"],pre["oa_urls"])
        self.assertEqual(out[0]["pdf_locations"][0]["version"],"submittedVersion")
        self.assertEqual(len(out[0]["source_records"]),2)
        self.assertEqual(core.deduplicate(out),out)
    def test_same_title_different_dois_not_merged(self):
        self.assertEqual(len(core.deduplicate([{"title":"X","doi":"10.1/x"},{"title":"X","doi":"10.1/y"}])),2)
    def test_filename_cannot_escape_directory(self):
        for title in ["../path:bad*name?","CON","nul.txt","A/\u0000B"," . "]:
            name=core.safe_filename(title)
            self.assertTrue(name)
            self.assertNotIn("/",name);self.assertNotIn("\\",name)
            self.assertNotIn(":",name)
            self.assertNotIn(name.split(".")[0].upper(),["CON","NUL"])
    def test_reference_exports_selected_only_and_csv_formula_escaped(self):
        with tempfile.TemporaryDirectory(dir=core.APP_DIR/"tests") as td:
            refs=core.export_references([{"title":"=1+1","authors":["A & B"],"doi":"10.1234/a","year":2025,"version":"期刊论文","sources":["Test"],"url":"https://example.org"}],td)
            with Path(refs["csv"]).open(encoding="utf-8-sig",newline="") as stream:
                rows=list(csv.reader(stream))
            self.assertEqual(rows[1][0],"'=1+1")
            self.assertEqual(len(rows),2)
            self.assertEqual(json.loads(Path(refs["json"]).read_text(encoding="utf8"))["count"],1)
            self.assertIn(r"A \& B",Path(refs["bibtex"]).read_text(encoding="utf8"))
            self.assertIn("TY  - JOUR",Path(refs["ris"]).read_text(encoding="utf8"))
    def test_book_is_not_exported_as_journal_article(self):
        with tempfile.TemporaryDirectory(dir=core.APP_DIR/"tests") as td:
            refs=core.export_references([{"title":"Volterra Integral Equations","doi":"10.1017/9781316162491","work_type":"book","version":"文献","year":2017}],td)
            self.assertIn("@book{",Path(refs["bibtex"]).read_text(encoding="utf8"))
            self.assertIn("TY  - BOOK",Path(refs["ris"]).read_text(encoding="utf8"))


class IdentityTests(unittest.TestCase):
    def test_same_title_year_never_overrides_distinct_bibliography(self):
        original = {"title": "Convergence", "year": 2026, "sources": ["OpenAIRE"]}
        records = [{**original, "authors": ["Alice"], "venue": "Journal A"},
                   {**original, "authors": ["Bob"], "venue": "Journal A"},
                   {**original, "authors": ["Alice"], "venue": "Journal B"}]
        result = core.deduplicate(records)
        self.assertEqual(len(result), 3)
        self.assertEqual(len({p["id"] for p in result}), 3)
        self.assertEqual(len(core.deduplicate(records + records)), 3)
        self.assertEqual(core.deduplicate(result), result)

    def test_sparse_records_with_different_pdf_links_do_not_collapse(self):
        records = [{"title": "Sparse title", "year": 2026, "sources": ["Repository"],
                    "pdf_urls": ["https://example.org/" + suffix]} for suffix in ("a.pdf", "b.pdf")]
        self.assertEqual(len(core.deduplicate(records)), 2)
        self.assertEqual(len({p["id"] for p in core.deduplicate(records)}), 2)

    def test_doi_hash_does_not_change(self):
        import hashlib
        self.assertEqual(core.paper_id({"doi": "https://doi.org/10.1234/ABC"}),
                         hashlib.sha256(b"doi:10.1234/abc").hexdigest()[:20])

    def test_arxiv_and_publication_bridge_is_order_independent(self):
        import itertools
        pre = {"title": "Old title", "arxiv_id": "arXiv:2401.01234v1", "version": "预印本", "sources": ["arXiv"],
               "pdf_urls": ["https://arxiv.org/pdf/2401.01234v1"],
               "pdf_locations": [{"url": "https://arxiv.org/pdf/2401.01234v1", "version": "submittedVersion"}]}
        journal = {"title": "Final title", "doi": "10.1000/published", "version": "期刊论文", "sources": ["Crossref"],
                   "authors": ["First", "Second"], "year": 2026, "publisher": "SIAM", "issns": ["1234-5678"]}
        bridge = {"title": "Old title", "doi": "10.1000/published", "arxiv_id": "2401.01234v2", "sources": ["OpenAlex"],
                  "pdf_urls": ["https://arxiv.org/pdf/2401.01234v2"],
                  "pdf_locations": [{"url": "https://arxiv.org/pdf/2401.01234v2", "version": "acceptedVersion"}]}
        expected = core.deduplicate([pre, journal, bridge])
        for order in itertools.permutations([pre, journal, bridge]):
            result = core.deduplicate(order)
            self.assertEqual(result, expected)
        result = expected[0]
        self.assertEqual(result["id"], core.paper_id(journal))
        self.assertEqual(result["title"], "Final title")
        self.assertEqual(result["authors"], ["First", "Second"])
        self.assertEqual(result["publisher"], "SIAM")
        self.assertEqual(result["issns"], ["1234-5678"])
        self.assertEqual(len(result["source_records"]), 3)
        self.assertEqual(len(result["pdf_locations"]), 2)
        self.assertEqual(core.deduplicate(expected), expected)

    def test_arxiv_doi_is_an_alias_not_a_conflicting_publication(self):
        records = [{"title": "Preprint", "doi": "10.48550/arXiv.2401.01234", "sources": ["OpenAlex"]},
                   {"title": "Preprint", "arxiv_id": "https://arxiv.org/abs/2401.01234v3", "sources": ["arXiv"]},
                   {"title": "Journal", "doi": "10.1000/journal", "arxiv_id": "2401.01234", "version": "期刊论文"}]
        result = core.deduplicate(records)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["doi"], "10.1000/journal")
        self.assertEqual({r["doi"] for r in result[0]["source_records"]}, {"", "10.48550/arxiv.2401.01234", "10.1000/journal"})

    def test_conflicting_publication_dois_keep_ambiguous_preprint_separate(self):
        import itertools
        records = [{"title": "A", "doi": "10.1000/a", "arxiv_id": "2401.01234"},
                   {"title": "B", "doi": "10.1000/b", "arxiv_id": "2401.01234"},
                   {"title": "Preprint", "arxiv_id": "2401.01234v1"},
                   {"title": "A extra", "doi": "10.1000/a", "sources": ["Crossref"]}]
        expected_ids = None
        for order in itertools.permutations(records):
            result = core.deduplicate(order)
            self.assertEqual(len(result), 3)
            actual = {p["id"] for p in result}
            self.assertEqual(len(actual), 3)
            if expected_ids is None:
                expected_ids = actual
            self.assertEqual(actual, expected_ids)
            self.assertEqual(core.deduplicate(result), result)

    def test_transitive_unidentified_bridge_cannot_merge_conflicting_dois(self):
        records = [{"title": "A", "doi": "10.1000/a", "arxiv_id": "2401.01234"},
                   {"title": "B", "doi": "10.1000/b", "arxiv_id": "2402.01234"},
                   {"title": "Bridge A", "arxiv_id": "2401.01234", "openaire_id": "shared"},
                   {"title": "Bridge B", "arxiv_id": "2402.01234", "openaire_id": "shared"}]
        result = core.deduplicate(records)
        self.assertEqual(len(result), 3)
        self.assertEqual(sorted(p["doi"] for p in result), ["", "10.1000/a", "10.1000/b"])
        self.assertEqual(core.deduplicate(result), result)

    def test_stable_provider_identifiers_and_arxiv_links_match(self):
        for field, a, b in [("openalex_id", "https://openalex.org/W1234", "W1234"),
                            ("openaire_id", "p-1234", "p-1234"), ("pmcid", "pmc1234", "PMC1234"),
                            ("hal_id", "hal-01234567v1", "hal-01234567v2")]:
            with self.subTest(field=field):
                self.assertEqual(len(core.deduplicate([{"title": "One", field: a},
                    {"title": "One published", field: b, "doi": "10.1000/a"}])), 1)
        self.assertEqual(len(core.deduplicate([
            {"title": "A", "url": "https://arxiv.org/pdf/math/0301234v2.pdf"},
            {"title": "A published", "doi": "10.1000/a", "arxiv_id": "math/0301234"}])), 1)

    def test_shared_generic_landing_page_is_not_identity(self):
        records = [{"title": "Same", "year": 2026, "authors": [name], "url": "https://journal.example/issue/1"}
                   for name in ("Alice", "Bob")]
        self.assertEqual(len(core.deduplicate(records)), 2)

    def test_inputs_are_not_mutated(self):
        import copy
        records = [{"title": "Test", "doi": "10.1000/a", "sources": ["arXiv"],
                    "pdf_locations": [{"url": "https://example.org/a.pdf", "version": "submittedVersion"}]},
                   {"title": "Test", "doi": "10.1000/a", "sources": ["Crossref"]}]
        before = copy.deepcopy(records)
        core.deduplicate(records)
        self.assertEqual(records, before)


class SettingsTests(unittest.TestCase):
    def test_crossref_migration_is_one_time_and_keeps_new_user_choice(self):
        with tempfile.TemporaryDirectory(dir=core.APP_DIR/"tests") as td, patch.object(core, "DATA_DIR", Path(td)):
            self.assertIn("crossref", core.load_settings()["sources"])
            core.atomic_json(Path(td)/"settings.json", {"settings_version": 2, "sources": ["arxiv"]})
            migrated = core.load_settings()
            self.assertEqual(migrated["sources"], ["arxiv", "crossref"])
            self.assertEqual(migrated["settings_version"], core.SETTINGS_VERSION)
            migrated["sources"] = ["arxiv"]
            core.save_settings(migrated)
            self.assertEqual(core.load_settings()["sources"], ["arxiv"])
