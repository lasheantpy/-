"""Offline regression tests for official supplementary index adapters."""
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

import extra_providers as e
import providers as p


def page(source, query="Volterra", **kwargs):
    args = dict(page_size=2, offset=0, cursor=None, year_from=None, year_to=None,
                sort="relevance", cancel_event=None)
    args.update(kwargs)
    return e.fetch_page(source, query, **args)


class NormalizationTests(unittest.TestCase):
    def test_openaire_retains_publisher_and_only_explicit_open_files(self):
        paper = e.normalize_openaire({
            "id": "openaire-1", "mainTitle": "Volterra equations", "publicationDate": "2024-03-01",
            "publisher": "SIAM", "container": {"name": "SIAM Journal", "issnPrinted": "1234-5678"},
            "pids": [{"scheme": "doi", "value": "https://doi.org/10.1234/ABC"}],
            "authors": [{"fullName": "B Author", "rank": 2}, {"fullName": "A Author", "rank": 1}],
            "instances": [
                {"type": "article", "accessRight": {"label": "OPEN"}, "urls": ["https://archive.test/file.pdf"]},
                {"type": "article", "accessRight": {"label": "CLOSED"}, "urls": ["https://publisher.test/paid.pdf"]}],
        })
        self.assertEqual(paper["doi"], "10.1234/abc")
        self.assertEqual(paper["publisher"], "SIAM")
        self.assertEqual(paper["issns"], ["1234-5678"])
        self.assertEqual(paper["authors"], ["A Author", "B Author"])
        self.assertEqual(paper["version"], "期刊论文")
        self.assertEqual(paper["pdf_urls"], ["https://archive.test/file.pdf"])

    def test_europepmc_oa_article_does_not_promote_subscription_link(self):
        paper = e.normalize_europepmc({
            "id": "1", "source": "MED", "isOpenAccess": "Y", "pmcid": "PMC123",
            "pubTypeList": {"pubType": ["Journal Article"]},
            "journalInfo": {"journal": {"title": "Modeling Journal", "issn": "1234-5678", "essn": "8765-4321"}},
            "fullTextUrlList": {"fullTextUrl": [
                {"url": "https://publisher.test/paid.pdf", "availabilityCode": "S", "documentStyle": "pdf"},
                {"url": "https://archive.test/open.pdf", "availabilityCode": "OA", "documentStyle": "pdf"}]},
        })
        self.assertEqual(paper["pdf_urls"], ["https://archive.test/open.pdf"])
        self.assertNotIn("https://publisher.test/paid.pdf", paper["oa_urls"])
        self.assertIn("https://europepmc.org/articles/PMC123", paper["oa_urls"])
        self.assertEqual(paper["issns"], ["1234-5678", "8765-4321"])
        self.assertEqual(paper["version"], "期刊论文")

    def test_hal_article_metadata_and_explicit_oa(self):
        paper = e.normalize_hal({
            "halId_s": "hal-012345", "title_s": ["A <i>method</i>"], "authFullName_s": ["A Author"],
            "producedDateY_i": 2024, "producedDate_s": "2024-01", "docType_s": "ART",
            "journalTitle_s": "Mathematics", "journalPublisher_s": "Springer Nature",
            "journalIssn_s": "1234-5678", "journalEissn_s": "8765-4321",
            "doiId_s": "10.1234/ABC", "arxivId_s": "2401.00001", "openAccess_bool": True,
            "fileMain_s": "https://hal.science/hal-012345/document", "uri_s": "https://hal.science/hal-012345v2",
        })
        self.assertEqual(paper["title"], "A method")
        self.assertEqual(paper["publisher"], "Springer Nature")
        self.assertEqual(paper["issns"], ["1234-5678", "8765-4321"])
        self.assertEqual(paper["version"], "期刊论文")
        self.assertEqual(paper["doi"], "10.1234/abc")
        self.assertEqual(paper["hal_id"], "hal-012345")
        self.assertEqual(paper["pdf_urls"], ["https://hal.science/hal-012345/document"])

    def test_hal_metadata_only_and_unsafe_links_never_count_as_open_pdf(self):
        for is_oa, file_url in [(False, "https://hal.science/a/document"), (True, "file:///D:/private.pdf")]:
            paper = e.normalize_hal({"halId_s": "hal-1", "fileMain_s": file_url, "openAccess_bool": is_oa})
            self.assertEqual(paper["pdf_urls"], [])
        self.assertFalse(e.normalize_hal({"halId_s": "hal-1", "fileMain_s": "https://hal.science/a/document"})["oa"])

    def test_optional_metadata(self):
        for normalize in (e.normalize_openaire, e.normalize_europepmc, e.normalize_hal):
            with self.subTest(provider=normalize.__name__):
                paper = normalize({})
                self.assertEqual(paper["title"], "（无标题）")
                self.assertEqual(paper["pdf_urls"], [])
                self.assertEqual(paper["publisher"], "")
                self.assertEqual(paper["issns"], [])


class AdapterTests(unittest.TestCase):
    def test_openaire_pagination_filters_and_sort(self):
        calls = []
        def request(url, source, cancel):
            params = parse_qs(urlsplit(url).query); calls.append(params)
            n = int(params["page"][0])
            return json.dumps({"header": {"numFound": 4}, "results": [
                {"id": f"oa-{i}", "mainTitle": f"Paper {i}", "pids": [{"scheme": "doi", "value": f"10.1234/{i}"}]}
                for i in range((n-1)*2, n*2)]}).encode()
        with patch.object(p, "_request", side_effect=request), patch.dict(p.SOURCE_PAGE_SIZES, {"openaire": 2}):
            result = p._fetch_source("openaire", "Volterra", 4, 2020, 2024, "citations", None)
        self.assertEqual([c["page"][0] for c in calls], ["1", "2"])
        self.assertIn("from_publication_year:2020", calls[0]["filter"][0])
        self.assertIn("to_publication_year:2024", calls[0]["filter"][0])
        self.assertEqual(calls[0]["sort"], ["citation_count:desc"])
        self.assertEqual(len(result["papers"]), 4)
        self.assertTrue(result["complete"])

    def test_europepmc_cursor_year_range_and_exhaustion(self):
        calls = []
        def request(url, source, cancel):
            params = parse_qs(urlsplit(url).query); calls.append(params)
            token = params["cursorMark"][0]
            indices = [0, 1] if token == "*" else [2]
            return json.dumps({"hitCount": 3, "nextCursorMark": "second" if token == "*" else "third",
                               "resultList": {"result": [{"title": f"Paper {i}", "doi": f"10.1234/{i}"} for i in indices]}}).encode()
        with patch.object(p, "_request", side_effect=request), patch.dict(p.SOURCE_PAGE_SIZES, {"europepmc": 2}):
            result = p._fetch_source("europepmc", "Volterra", 5, 2020, 2024, "year", None)
        self.assertEqual([c["cursorMark"][0] for c in calls], ["*", "second"])
        self.assertIn("FIRST_PDATE:[2020-01-01 TO 2024-12-31]", calls[0]["query"][0])
        self.assertEqual(len(result["papers"]), 3)
        self.assertTrue(result["exhausted"])

    def test_europepmc_missing_or_stalled_cursor_preserves_page_as_partial(self):
        for cursor in (None, "*"):
            payload = {"hitCount": 5, "resultList": {"result": [{"title": "Paper", "doi": "10.1234/1"}]}}
            if cursor is not None:
                payload["nextCursorMark"] = cursor
            with self.subTest(cursor=cursor), patch.object(p, "_request", return_value=json.dumps(payload).encode()) as req:
                result = p._fetch_source("europepmc", "Volterra", 4, None, None, "relevance", None)
            self.assertEqual(req.call_count, 1)
            self.assertEqual(len(result["papers"]), 1)
            self.assertFalse(result["complete"])
            self.assertFalse(result["exhausted"])
            self.assertEqual(result["end_reason"], "no_progress")
            self.assertIn("游标", result["error"])

    def test_hal_pagination_and_year_sort(self):
        calls = []
        def request(url, source, cancel):
            params = parse_qs(urlsplit(url).query); calls.append(params)
            offset = int(params["start"][0])
            return json.dumps({"response": {"numFound": 4, "docs": [
                {"halId_s": f"hal-{i}", "title_s": [f"Paper {i}"], "doiId_s": f"10.1234/{i}"}
                for i in range(offset, offset+2)]}}).encode()
        with patch.object(p, "_request", side_effect=request), patch.dict(p.SOURCE_PAGE_SIZES, {"hal": 2}):
            result = p._fetch_source("hal", "Volterra", 4, 2020, 2024, "year", None)
        self.assertEqual([c["start"][0] for c in calls], ["0", "2"])
        self.assertEqual(calls[0]["fq"], ["producedDateY_i:[2020 TO 2024]"])
        self.assertEqual(calls[0]["sort"], ["producedDate_tdate desc,docid asc"])
        self.assertEqual(len(result["papers"]), 4)
        self.assertEqual(result["pages"], 2)

    def test_hal_missing_citations_are_explained(self):
        result = page("hal", sort="citations", request=lambda *_: b'{"response":{"numFound":0,"docs":[]}}')
        self.assertTrue(result["exhausted"])
        self.assertIn("不提供引用次数", result["warnings"][0])

    def test_hal_failure_on_later_page_keeps_results_and_error(self):
        def request(url, source, cancel):
            offset = int(parse_qs(urlsplit(url).query)["start"][0])
            if offset:
                raise p.ProviderError("测试 HTTP 503。")
            return b'{"response":{"numFound":4,"docs":[{"title_s":["Paper"],"halId_s":"hal-1"}]}}'
        with patch.object(p, "_request", side_effect=request), patch.dict(p.SOURCE_PAGE_SIZES, {"hal": 1}):
            result = p._fetch_source("hal", "Volterra", 3, None, None, "relevance", None)
        self.assertEqual(len(result["papers"]), 1)
        self.assertFalse(result["complete"])
        self.assertEqual(result["end_reason"], "page_failed")
        self.assertIn("503", result["error"])

    def test_cancel_after_completed_hal_page_does_not_fetch_next(self):
        event = threading.Event()
        def request(*args):
            return b'{"response":{"numFound":4,"docs":[{"title_s":["Paper"],"halId_s":"hal-1"}]}}'
        with patch.object(p, "_request", side_effect=request) as req, patch.dict(p.SOURCE_PAGE_SIZES, {"hal": 1}):
            result = p._fetch_source("hal", "Volterra", 3, None, None, "relevance", event, on_page=lambda _: event.set())
        self.assertEqual(req.call_count, 1)
        self.assertEqual(len(result["papers"]), 1)
        self.assertEqual(result["end_reason"], "cancelled")
        self.assertFalse(result["complete"])

    def test_malformed_pages_do_not_report_success(self):
        for source in e.SOURCE_NAMES:
            with self.subTest(source=source):
                with self.assertRaises(RuntimeError):
                    page(source, request=lambda *_: b'{}')


if __name__ == "__main__":
    unittest.main()
