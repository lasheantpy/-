import unittest
from urllib.parse import parse_qs,urlsplit
import publisher_catalog


class PublisherLinkTests(unittest.TestCase):
    def test_required_publishers_and_query_roundtrip(self):
        self.assertTrue({"elsevier","springer","wiley","siam","ams"}.issubset(publisher_catalog.PUBLISHERS))
        query='Volterra C++ & α # "delay" / 积分'
        for key,entry in publisher_catalog.PUBLISHERS.items():
            with self.subTest(publisher=key):
                url=urlsplit(publisher_catalog.search_link(key,query))
                self.assertEqual(url.scheme,"https")
                self.assertEqual(url.netloc,urlsplit(entry["url"]).netloc)
                if entry["query_key"]:
                    self.assertEqual(parse_qs(url.query),{entry["query_key"]:[query]})
                    self.assertFalse(url.fragment)
                else:
                    self.assertEqual(url.query,"")
                    self.assertIn("复制关键词",publisher_catalog.publisher_note(key))

    def test_blank_query_and_unknown_publisher_are_rejected(self):
        with self.assertRaises(ValueError):publisher_catalog.search_link("siam","  ")
        with self.assertRaises(KeyError):publisher_catalog.search_link("https://example.com","Volterra")
