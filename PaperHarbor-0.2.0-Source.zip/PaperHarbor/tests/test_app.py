import tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
import core,app

class UITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=core.APP_DIR/"tests")
        self.patch=patch.object(core,"DATA_DIR",Path(self.tmp.name)/"data");self.patch.start()
        self.window=app.PaperHarborApp();self.window.withdraw()
        self.window.folder_var.set(str(Path(self.tmp.name)/"library"))
        self.window.papers=[];self.window.by_id={};self.window.render_results()
    def tearDown(self):
        if not self.window._closing:self.window._close()
        self.window=None
        import gc
        gc.collect()
        self.patch.stop();self.tmp.cleanup()
    def finish(self):
        end=time.monotonic()+5
        while self.window._busy and time.monotonic()<end:
            self.window.update();time.sleep(.01)
        self.window.update()
        self.assertFalse(self.window._busy)
    def test_search_select_download_and_si_retry(self):
        records=core.deduplicate([
          {"title":"Integral equations A","doi":"10.1234/a","year":2025,"pdf_urls":["https://example.org/a.pdf"],"sources":["Test"]},
          {"title":"Integral equations B","doi":"10.1234/b","year":2024,"pdf_urls":[],"sources":["Test"]}])
        with patch("app.providers.search",return_value={"papers":records,"warnings":[],"sources":{"test":{"count":2,"status":"ok"}}}) as search:
            self.window.query_var.set("integral equations");self.window.start_search();self.finish()
        self.assertEqual(len(self.window.tree.get_children()),2)
        self.assertEqual(search.call_args.kwargs["sources"],["openalex","arxiv","crossref","openaire"])
        self.window.pdf_only_var.set(True);self.window.render_results();self.window.select_all()
        self.assertEqual(len(self.window.selected_papers()),1)
        def download(papers,out_dir,**kw):
            self.assertTrue(kw["include_supplements"])
            self.assertEqual([p["title"] for p in papers],["Integral equations A"])
            kw["progress"]({"id":papers[0]["id"],"status":"supplements","current":1,"total":1,"message":"SI"})
            return {"results":[{"id":papers[0]["id"],"status":"downloaded","si_status":"incomplete","supplements":[],"path":"a.pdf","manual_urls":["https://example.org"]}],"manifest_path":str(Path(out_dir)/"manifest.json")}
        with patch("app.downloader.download_batch",side_effect=download):
            self.window.start_download();self.finish()
        self.assertTrue(self.window.last_manifest.endswith("manifest.json"))
        self.window.clear_selection();self.window.select_failed()
        self.assertEqual(len(self.window.checked),1)
        self.window.tree.selection_set(records[0]["id"]);self.window._show_details()
        self.assertIn("检查未完成",self.window.details.get("1.0","end"))
    def test_validation_prevents_network(self):
        with patch("app.providers.search") as search:
            self.window.year_from_var.set("2025");self.window.year_to_var.set("2020")
            self.window.start_search();search.assert_not_called()
            self.assertIn("年份",self.window.status_var.get())
    def test_cancel_search_preserves_completion(self):
        def search(query,**kw):
            kw["cancel_event"].wait(2)
            return {"papers":[],"warnings":[],"sources":{},"cancelled":True}
        with patch("app.providers.search",side_effect=search):
            self.window.start_search();self.window.cancel();self.finish()
        self.assertTrue(self.window._cancel.is_set())
    def test_close_during_download_waits_for_manifest(self):
        records=core.deduplicate([{"title":"X","doi":"10.1234/x","pdf_urls":[]}])
        self.window.papers=records;self.window.by_id={p["id"]:p for p in records}
        self.window.render_results();self.window.select_all()
        done=threading.Event()
        def download(papers,out_dir,**kw):
            kw["cancel_event"].wait(2)
            done.set()
            return {"results":[{"id":papers[0]["id"],"status":"cancelled","si_status":"cancelled","supplements":[]}],"manifest_path":str(Path(out_dir)/"cancelled.json")}
        with patch("app.downloader.download_batch",side_effect=download):
            self.window.start_download();self.window._close()
            end=time.monotonic()+5
            while not self.window._closing and time.monotonic()<end:
                self.window.update();time.sleep(.01)
        self.assertTrue(done.is_set());self.assertTrue(self.window._closing)
    def test_batch_error_marks_unfinished_rows_retryable(self):
        records=core.deduplicate([{"title":"X","doi":"10.1234/x","pdf_urls":[]}])
        self.window.papers=records;self.window.by_id={p["id"]:p for p in records}
        self.window.render_results();self.window.select_all()
        with self.assertLogs(level="ERROR"), patch("app.core.export_references",side_effect=OSError("disk write failed")):
            self.window.start_download();self.finish()
        self.assertEqual(self.window.results[records[0]["id"]]["status"],"failed")
        self.window.clear_selection();self.window.select_failed()
        self.assertEqual(self.window.checked,{records[0]["id"]})

    def test_dynamic_sources_and_publisher_query_are_separate(self):
        from urllib.parse import urlsplit,parse_qs
        self.assertEqual(set(self.window.source_checkboxes),set(app.providers.SOURCE_NAMES))
        self.window.query_var.set('C++ & Volterra 积分')
        original=list(self.window.papers)
        self.window.publisher_var.set(app.publisher_catalog.PUBLISHERS["siam"]["name"])
        with patch("app.webbrowser.open",return_value=True) as browser, patch("app.providers.search") as search:
            self.window.open_publisher()
        url=browser.call_args.args[0]
        self.assertEqual(urlsplit(url).hostname,"epubs.siam.org")
        self.assertEqual(parse_qs(urlsplit(url).query)["AllField"],["C++ & Volterra 积分"])
        search.assert_not_called()
        self.assertEqual(self.window.papers,original)
        self.assertIn("不会自动汇入",self.window.status_var.get())
        self.window.publisher_var.set(app.publisher_catalog.PUBLISHERS["ams"]["name"])
        self.window._publisher_changed()
        self.assertIn("复制关键词",self.window.publisher_note_var.get())

    def test_current_result_venue_filter_and_publisher_details(self):
        records=core.deduplicate([
            {"title":"A","doi":"10.1234/a","venue":"SIAM Journal on Numerical Analysis","publisher":"SIAM","issns":["0036-1429"]},
            {"title":"B","doi":"10.1234/b","venue":"Journal of Computational Physics","publisher":"Elsevier"}])
        self.window.papers=records;self.window.by_id={p["id"]:p for p in records}
        self.window.venue_filter_var.set("elsevier");self.window.render_results()
        self.assertEqual(self.window.tree.get_children(),(records[1]["id"],))
        self.window.venue_filter_var.set("numerical analysis");self.window.render_results()
        self.assertEqual(self.window.tree.get_children(),(records[0]["id"],))
        self.window.tree.selection_set(records[0]["id"]);self.window._show_details()
        self.assertIn("出版社：SIAM",self.window.details.get("1.0","end"))
        self.assertIn("0036-1429",self.window.details.get("1.0","end"))
        self.window.venue_filter_var.set("");self.window.render_results()
        self.assertEqual(len(self.window.tree.get_children()),2)

    def test_source_failure_partial_and_cache_are_visible(self):
        info={"openalex":{"status":"failed","count":0,"pages":0,"complete":False,"error":"HTTP 429"},
              "crossref":{"status":"partial","count":100,"pages":1,"total":1000,"complete":False,"error":"timeout"},
              "arxiv":{"status":"stale_cache","count":12,"pages":1,"error":"connection failed"}}
        with patch("app.providers.search",return_value={"papers":[],"warnings":["网络连接失败"],"sources":info}):
            self.window.start_search();self.finish()
        compact=self.window.source_status_var.get()
        self.assertIn("失败",compact);self.assertIn("部分完成",compact);self.assertIn("历史缓存",compact)
        detailed=self.window._source_details_text()
        for expected in ("HTTP 429","timeout","connection failed","取回 100 条","索引匹配 1000 条","未完成","可能过期"):
            self.assertIn(expected,detailed)

    def test_more_results_preserves_selection_and_download_state(self):
        records=core.deduplicate([{"title":"A","doi":"10.1234/a"},{"title":"B","doi":"10.1234/b"}])
        self.window.limit_var.set("30")
        with patch("app.providers.search",return_value={"papers":records[:1],"warnings":[],"sources":{}}):
            self.window.start_search();self.finish()
        self.window.select_all()
        first=records[0]["id"]
        self.window.results[first]={"id":first,"status":"downloaded","path":"a.pdf"}
        with patch("app.providers.search",return_value={"papers":records,"warnings":[],"sources":{}}) as search:
            self.window.more_results();self.finish()
        self.assertEqual(search.call_args.kwargs["limit"],100)
        self.assertEqual(self.window.checked,{first})
        self.assertEqual(self.window.results[first]["status"],"downloaded")
        self.window.limit_var.set("500")
        with patch("app.providers.search") as search:
            self.window.more_results();search.assert_not_called()
        self.assertIn("上限",self.window.status_var.get())

    def test_open_pdf_report_and_unavailable_record(self):
        folder=Path(self.tmp.name)
        pdf=folder/"verified.pdf";pdf.write_bytes(b"%PDF-1.4\n")
        html=folder/"download-report.html";html.write_text("<html>Report</html>")
        records=core.deduplicate([{"title":"A","doi":"10.1234/a"}])
        iid=records[0]["id"]
        self.window.papers=records;self.window.by_id={iid:records[0]};self.window.render_results()
        self.window.tree.selection_set(iid)
        self.window.results[iid]={"id":iid,"status":"downloaded","path":str(pdf)}
        with patch("app.os.startfile") as opener:
            self.window.open_pdf();opener.assert_called_once_with(str(pdf))
        self.window.results[iid]={"id":iid,"status":"unavailable","path":str(folder/"record.json")}
        with patch("app.os.startfile") as opener:
            self.window.open_pdf();opener.assert_not_called()
        self.assertIn("JSON",self.window.status_var.get())
        self.window.last_report=str(html)
        with patch("app.webbrowser.open") as opener:
            self.window.open_report();opener.assert_called_once_with(html.resolve().as_uri())
