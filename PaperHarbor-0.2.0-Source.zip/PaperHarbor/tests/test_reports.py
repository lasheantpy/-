import tempfile, unittest
from pathlib import Path
from html.parser import HTMLParser
import core


class Links(HTMLParser):
    def __init__(self, text):
        super().__init__()
        self.hrefs = []
        self.scripts = 0
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            self.hrefs.extend(v for k, v in attrs if k == "href")
        if tag == "script":
            self.scripts += 1


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=core.APP_DIR / "tests")
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)

    def report(self, results, summary=None):
        manifest = self.folder / "manifest.json"
        manifest.write_text("{}", encoding="utf8")
        path = core.write_download_report({"manifest_path": str(manifest), "results": results, "summary": summary or {}})
        self.assertEqual(Path(path), manifest.with_suffix(".html"))
        return Path(path).read_text(encoding="utf8")

    def test_only_existing_pdf_with_success_status_is_counted(self):
        pdf = self.folder / "paper.pdf"
        pdf.write_bytes(b"%PDF-1.4\nlocal fixture")
        metadata = self.folder / "only.json"
        metadata.write_text("{}", encoding="utf8")
        fake = self.folder / "fake.pdf"
        fake.write_text("{}", encoding="utf8")
        content = self.report([
            {"title": "PDF", "status": "downloaded", "path": str(pdf)},
            {"title": "Missing", "status": "existing", "path": str(self.folder/"gone.pdf")},
            {"title": "JSON", "status": "downloaded", "path": str(metadata)},
            {"title": "Fake", "status": "downloaded", "path": str(fake)},
            {"title": "Failed", "status": "failed", "path": str(pdf)}])
        self.assertIn("可打开的正文 PDF 1 / 5", content)
        self.assertEqual(Links(content).hrefs, [pdf.as_uri()])
        self.assertIn("本地文件已缺失", content)
        self.assertIn("只有 JSON 不代表", content)

    def test_relative_paths_resolve_against_manifest_folder(self):
        pdf = self.folder / "paper.pdf"
        pdf.write_bytes(b"%PDF-1.7\n")
        content = self.report([{"status": "existing", "path": "paper.pdf"}])
        self.assertIn("正文 PDF 1 / 1", content)
        self.assertEqual(Links(content).hrefs, [pdf.as_uri()])

    def test_untrusted_text_is_escaped_and_bad_links_are_filtered(self):
        safe = "https://example.org/article?a=1&b=2"
        content = self.report([{"title": '<script>alert("title")</script>', "status": "failed",
            "error": '<img src=x onerror="boom">', "si_message": "<bad> & text",
            "manual_urls": [safe, safe, "javascript:alert(1)", "file:///C:/bad.exe", "https://user:password@example.org/",
                            "https://example.org:invalid/", "https://example.org/\nunsafe", None, "https://[invalid"]}])
        self.assertEqual(Links(content).scripts, 0)
        self.assertEqual(Links(content).hrefs, [safe])
        self.assertIn("&lt;script&gt;", content)
        self.assertNotIn("javascript:", content)
        self.assertIn("&lt;bad&gt; &amp; text", content)

    def test_cancelled_batch_discloses_unprocessed_selection(self):
        content = self.report([{"title": "Cancelled", "status": "cancelled"}], {"total": 5})
        self.assertIn("正文 PDF 0 / 5", content)
        self.assertIn("已处理 1 / 5 篇；其余尚未处理", content)
        self.assertIn("已取消", content)

    def test_supplement_links_require_saved_supported_files(self):
        attachment = self.folder / "data & notes.csv"
        attachment.write_text("x,y\n1,2\n", encoding="utf8")
        executable = self.folder / "untrusted.exe"
        executable.write_bytes(b"fake")
        content = self.report([{"status": "unavailable", "supplements": [
            {"status": "downloaded", "path": str(attachment)},
            {"status": "existing", "path": str(self.folder/"missing.zip")},
            {"status": "downloaded", "path": str(executable)},
            {"status": "failed", "error": "<failure>"}]}])
        self.assertEqual(Links(content).hrefs, [attachment.as_uri()])
        self.assertIn("2 个记录中的补充文件不可打开", content)
        self.assertIn("&lt;failure&gt;", content)
